import java.util.ArrayList;

public class VMCacheSim {

    public static void main(String[] args) {

        int cacheSizeKB = 512;
        int blockSize = 16;
        int associativity = 4;
        String replacementPolicy = "Round Robin";
        int physicalMemoryMB = 128;
        int instructionsPerTimeSlice = -1;
        double percentMemoryUsed = 75.0;
        ArrayList<String> traceFiles = new ArrayList<>();

        // ------------------ ARG PARSING ------------------
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-s": cacheSizeKB = Integer.parseInt(args[++i]); break;
                case "-b": blockSize = Integer.parseInt(args[++i]); break;
                case "-a": associativity = Integer.parseInt(args[++i]); break;
                case "-r":
                    replacementPolicy =
                            args[++i].equalsIgnoreCase("RR") ? "Round Robin" : "Random";
                    break;
                case "-p": physicalMemoryMB = Integer.parseInt(args[++i]); break;
                case "-n": instructionsPerTimeSlice = Integer.parseInt(args[++i]); break;
                case "-u": percentMemoryUsed = Double.parseDouble(args[++i]); break;
                case "-f": traceFiles.add(args[++i]); break;
                default:
                    System.out.println("Unknown argument: " + args[i]);
            }
        }

        // ====================== MILESTONE 1 ======================
        System.out.println("Cache Simulator - CS 3853 - Team #05\n");
        System.out.println("Trace File(s):");
        for (String f : traceFiles)
            System.out.println("        " + f);

        System.out.println("\n***** Cache Input Parameters *****\n");
        System.out.printf("Cache Size:                     %d KB\n", cacheSizeKB);
        System.out.printf("Block Size:                     %d bytes\n", blockSize);
        System.out.printf("Associativity:                  %d\n", associativity);
        System.out.printf("Replacement Policy:             %s\n", replacementPolicy);
        System.out.printf("Physical Memory:                %d MB\n", physicalMemoryMB);
        System.out.printf("Percent Memory Used by System:  %.1f%%%n", percentMemoryUsed);
        System.out.printf("Instructions / Time Slice:      %s%n\n",
                (instructionsPerTimeSlice < 0 ? "ALL" : instructionsPerTimeSlice));

        int blockOffsetSize = (int)(Math.log(blockSize)/Math.log(2));
        int totalBlocks = (cacheSizeKB * 1024) / blockSize;
        int totalRows = totalBlocks / associativity;
        int indexSize = (int)(Math.log(totalRows)/Math.log(2));

        double physicalMemoryMBLog2 = Math.log(physicalMemoryMB) / Math.log(2);
        int physicalAddressBits = (int)Math.round(physicalMemoryMBLog2 + 20.0);
        int tagSize = physicalAddressBits - indexSize - blockOffsetSize;

        int overheadSizeBytes = totalBlocks * (tagSize + 1) / 8;
        int implementationBytes = cacheSizeKB * 1024 + overheadSizeBytes;
        double implKB = implementationBytes / 1024.0;
        double cost = implKB * 0.07;

        System.out.println("***** Cache Calculated Values *****\n");
        System.out.printf("Total # Blocks:                 %d\n", totalBlocks);
        System.out.printf("Tag Size:                       %d bits\n", tagSize);
        System.out.printf("Index Size:                     %d bits\n", indexSize);
        System.out.printf("Total # Rows:                   %d\n", totalRows);
        System.out.printf("Overhead Size:                  %d bytes\n", overheadSizeBytes);
        System.out.printf("Implementation Memory Size:     %.2f KB (%d bytes)\n",
                implKB, implementationBytes);
        System.out.printf("Cost:                           $%.2f @ $0.07 per KB\n\n", cost);

        // physical memory
        int pageSize = 4096;
        long physBytes = (long)physicalMemoryMB * 1024 * 1024;
        long numPhysPages = physBytes / pageSize;
        long systemPages = Math.round((percentMemoryUsed/100.0) * numPhysPages);
        long pteBits = 16;
        long pageTableBytes = 512L * 1024L * pteBits / 8;

        System.out.println("***** Physical Memory Calculated Values *****\n");
        System.out.printf("Number of Physical Pages:       %d%n", numPhysPages);
        System.out.printf("Number of Pages for System:     %d%n", systemPages);
        System.out.printf("Size of Page Table Entry:       %d bits%n", pteBits);
        System.out.printf("Total RAM for Page Table(s):    %d bytes%n\n", pageTableBytes);

        // ====================== MILESTONE 2 ======================
        VirtualMemoryManager vmm = new VirtualMemoryManager(physicalMemoryMB, percentMemoryUsed);

        for (int i = 0; i < traceFiles.size(); i++) {
            try {
                TraceFile tf = new TraceFile(traceFiles.get(i), i);
                vmm.processTrace(tf);
            } catch (Exception e) {
                System.out.println("Error reading trace: " + traceFiles.get(i));
            }
        }

        vmm.printMilestone2Output(traceFiles);

        // ====================== MILESTONE 3 ======================

        CacheSimulator cacheSim = new CacheSimulator(
                cacheSizeKB, blockSize, associativity,
                replacementPolicy.equals("Round Robin"),
                physicalAddressBits
        );

       

                   cacheSim.addPageFaults(vmm.totalPageFaults);
  

        for (int i = 0; i < traceFiles.size(); i++) {
            try {
                TraceFile tf2 = new TraceFile(traceFiles.get(i), i);
                TraceAccess acc;

                while ((acc = tf2.nextAccess()) != null) {

                    // FIZA - unlikely issue
                    cacheSim.access(acc.eipAddr, acc.eipLen, true);

                    //unlikely the issue i am pretty confident in this 
                    if (acc.dstAddr != null)
                        cacheSim.access(acc.dstAddr, 4, false);

                   
                    if (acc.srcAddr != null)
                        cacheSim.access(acc.srcAddr, 4, false);
             

 }

            } catch (Exception e) { }
        }

        cacheSim.printResults(vmm.physicalPagesSystem, vmm.physicalPagesFree,
                overheadSizeBytes, implementationBytes, vmm.getVirtualPagesMapped() );
    }
}

