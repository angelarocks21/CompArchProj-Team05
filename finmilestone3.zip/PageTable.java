import java.util.HashMap;

public class PageTable {

    private final HashMap<Integer,Integer> map = new HashMap<>();

    public int getPhysicalPage(int vpn) {
        Integer val = map.get(vpn);
	return (val == null) ? -1 : val;

    }

    public void map(int vpn, int ppn) {
        map.put(vpn, ppn);
    }

    public int countUsed() {
        return map.size();
    }
}

