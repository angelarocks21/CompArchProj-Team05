public class TraceAccess {
    int pid;
    long eipAddr;
    int eipLen;
    Long dstAddr;
    Long srcAddr;

    public TraceAccess(int pid, long eipAddr, int eipLen, Long dstAddr, Long srcAddr) {
        this.pid = pid;
        this.eipAddr = eipAddr;
        this.eipLen = eipLen;
        this.dstAddr = dstAddr;
        this.srcAddr = srcAddr;
    }
}

