import java.io.*;

public class TraceFile {
    private final BufferedReader br;
    int pid;

    public TraceFile(String filename, int pid) throws Exception {
        this.pid = pid;
        br = new BufferedReader(new FileReader(filename));
    }

    public TraceAccess nextAccess() throws Exception {

        String eipLine = br.readLine();
        if (eipLine == null) return null;

        // Skip blank lines before the EIP line
        while (eipLine != null && eipLine.trim().isEmpty()) {
            eipLine = br.readLine();
        }
        if (eipLine == null) return null;

        // ---------------- PARSE EIP LINE ----------------

        int lenStart = eipLine.indexOf('(') + 1;
        int lenEnd   = eipLine.indexOf(')');
        int instrLen = Integer.parseInt(eipLine.substring(lenStart, lenEnd)); // decimal length

        String afterColon = eipLine.split(":")[1].trim();
        String eipHex = afterColon.split("\\s+")[0];
        long eipAddr = Long.parseLong(eipHex, 16);

        // ---------------- READ MEMORY LINE ----------------
        String memLine = br.readLine();
        while (memLine != null && memLine.trim().isEmpty()) {
            memLine = br.readLine();
        }
        if (memLine == null) return null;


        String[] dstParts = memLine.split("dstM:")[1].trim().split("\\s+");
        String dstAddrHex = dstParts[0];
        Long dstAddr = (dstAddrHex.equals("00000000") || dstAddrHex.equals("--------"))
                ? null : Long.parseLong(dstAddrHex, 16);

        String[] srcParts = memLine.split("srcM:")[1].trim().split("\\s+");
        String srcAddrHex = srcParts[0];
        Long srcAddr = (srcAddrHex.equals("00000000") || srcAddrHex.equals("--------"))
                ? null : Long.parseLong(srcAddrHex, 16);

        return new TraceAccess(pid, eipAddr, instrLen, dstAddr, srcAddr);
    }
}

