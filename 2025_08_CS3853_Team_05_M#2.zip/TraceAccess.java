public class TraceAccess {
    int pid;
    long eipAddr;
    int eipLen;
    Long dstAddr;
    Long srcAddr;

    public TraceAccess(int pid, long eip, int len, Long dst, Long src) {
        this.pid = pid;
        this.eipAddr = eip;
        this.eipLen = len;
        this.dstAddr = dst;
        this.srcAddr = src;
    }
}

