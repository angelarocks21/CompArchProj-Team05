import java.util.*;

public class VirtualMemoryManager {

    private static final int PAGE_SIZE = 4096;

    int physicalPagesTotal;
    int physicalPagesSystem;
    int physicalPagesFree;

    Queue<Integer> freeList = new LinkedList<>();
    int evictionIndex = 0;

    ArrayList<PageTable> processTables = new ArrayList<>();

    long virtualPagesMapped = 0;  // number of mapping events (misses)
    long pageTableHits = 0;
    long pagesFromFree = 0;
    long totalPageFaults = 0;

    public VirtualMemoryManager(int physicalMB, double percentOS) {
        physicalPagesTotal = (physicalMB * 1024 * 1024) / PAGE_SIZE;
        physicalPagesSystem = (int) Math.round((percentOS / 100.0) * physicalPagesTotal);
        physicalPagesFree = physicalPagesTotal - physicalPagesSystem;

        // Fill free list with user-available physical pages
        for (int i = physicalPagesSystem; i < physicalPagesTotal; i++) {
            freeList.add(i);
        }
    }

    // One TraceFile = one process / page table
    public void processTrace(TraceFile tf) throws Exception {
        PageTable pt = new PageTable();
        processTables.add(pt);

        TraceAccess acc;
        while ((acc = tf.nextAccess()) != null) {

            // Instruction bytes
            for (int i = 0; i < acc.eipLen; i++) {
                mapAddress(pt, acc.eipAddr + i);
            }

            // dstM (4 bytes)
            if (acc.dstAddr != null) {
                long base = acc.dstAddr;
                for (int i = 0; i < 4; i++) {
                    mapAddress(pt, base + i);
                }
            }

            // srcM (4 bytes)
            if (acc.srcAddr != null) {
                long base = acc.srcAddr;
                for (int i = 0; i < 4; i++) {
                    mapAddress(pt, base + i);
                }
            }
        }
    }

    // Step 2 & 3 mapping logic
    private void mapAddress(PageTable pt, long vaddr) {
        int vpn = (int) (vaddr / PAGE_SIZE);

        // Check page table
        int phys = pt.getPhysicalPage(vpn);

        // HIT
        if (phys != -1) {
            pageTableHits++;
            return;
        }

        // MISS
        virtualPagesMapped++;

        if (!freeList.isEmpty()) {
            int newPPN = freeList.remove();
            pagesFromFree++;
            pt.map(vpn, newPPN);
        } else {
            totalPageFaults++;

            // simple round-robin over user frames only
            int userStart = physicalPagesSystem;
            int userCount = physicalPagesFree;
            int victimPPN = userStart + (evictionIndex % userCount);
            evictionIndex++;

            pt.map(vpn, victimPPN);
        }
    }

    public void printMilestone2Output(ArrayList<String> files) {
        System.out.println("\n\n***** VIRTUAL MEMORY SIMULATION RESULTS *****\n");

        System.out.printf("Physical Pages Used By SYSTEM:  %d%n", physicalPagesSystem);
        System.out.printf("Pages Available to User:        %d%n%n", physicalPagesFree);

        System.out.printf("Virtual Pages Mapped:           %d%n", virtualPagesMapped);
        System.out.println("---------------------------------------");
        System.out.printf("        Page Table Hits:        %d%n", pageTableHits);
        System.out.printf("        Pages from Free:        %d%n", pagesFromFree);
        System.out.printf("        Total Page Faults:      %d%n%n", totalPageFaults);

        System.out.println("Page Table Usage Per Process:");
        System.out.println("------------------------------");

        long totalEntriesPerTable = 512L * 1024L;   // 512K entries
        long bitsPerEntry = 19L;                    // 19-bit PTE

        for (int i = 0; i < processTables.size(); i++) {
            PageTable pt = processTables.get(i);
            int used = pt.countUsed();

            double percentUsed = (used / (double) totalEntriesPerTable) * 100.0;

            long usedBits = used * bitsPerEntry;
            long totalBits = totalEntriesPerTable * bitsPerEntry;
            long wastedBits = totalBits - usedBits;
            long wastedBytes = wastedBits / 8;

            System.out.println("[" + i + "] " + files.get(i));
            System.out.printf("   Used Page Table Entries: %d   ( %.02f%% )%n", used, percentUsed);
            System.out.println("   Page Table Wasted:       " + wastedBytes + " bytes\n");
        }
    }
}

