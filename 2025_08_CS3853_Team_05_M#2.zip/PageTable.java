public class PageTable {

    final int NUM_PTE = 512 * 1024;

    int[] physPage = new int[NUM_PTE];

    public PageTable() {
        for (int i = 0; i < NUM_PTE; i++)
            physPage[i] = -1;
    }

    public int getPhysicalPage(int vpn) {
        return physPage[vpn];
    }

    public void map(int vpn, int ppn) {
        physPage[vpn] = ppn;
    }

    public int countUsed() {
        int c = 0;
        for (int x : physPage)
            if (x != -1) c++;
        return c;
    }
}

