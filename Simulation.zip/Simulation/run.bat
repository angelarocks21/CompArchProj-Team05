@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM -----------------------------
REM Automated Cache Simulation Script
REM -----------------------------

SET SIM=VMCacheSim.exe
SET TRACE=S.trc

REM Cache sizes in KB
SET CACHES=8 64 256 1024

REM Block sizes in bytes
SET BLOCKS=4 16 64

REM Associativities (only 2 for your case)
SET ASSOC=4 8

REM Replacement policies
SET POL=RR RND

REM Physical memory (MB)
SET MEMS=1024 2048

REM Output CSV
SET OUT=results_for_S.csv

REM CSV header
echo Trace,CacheKB,Block,Associ,Re_Policy,Miss_rate,CPI,Unused_cache_space,$Waste/chip,PhysiMemMB,Page_fault > %OUT%

REM Initialize run counter
SET COUNT=0

REM -----------------------------
REM Loop through all combinations
REM -----------------------------
FOR %%c IN (%CACHES%) DO (
    FOR %%b IN (%BLOCKS%) DO (
        FOR %%a IN (%ASSOC%) DO (
            FOR %%p IN (%POL%) DO (
                FOR %%m IN (%MEMS%) DO (

                    SET /A COUNT+=1
                    echo Running !COUNT!: %SIM% -s %%c -b %%b -a %%a -r %%p -p %%m -f %TRACE% -n -1

                    REM Run simulator and redirect output to temp.txt
                    %SIM% -s %%c -b %%b -a %%a -r %%p -p %%m -f %TRACE% -n -1 > temp.txt

                    REM -----------------------------
                    REM Extract metrics robustly
                    REM -----------------------------

                    REM Miss Rate
                    for /f "tokens=3*" %%x in ('findstr /c:"Miss Rate" temp.txt') do set MISS=%%x
                    set MISS=!MISS: =!  

                    REM CPI
                    for /f "tokens=2*" %%x in ('findstr /c:"CPI:" temp.txt') do set CPI_LINE=%%x
                    for /f "tokens=1" %%y in ("!CPI_LINE!") do set CPI=%%y

                    REM Grab the line after colon
		    for /f "tokens=10*" %%x in ('findstr /c:"Unused Cache Space" temp.txt') do set WASTE_LINE=%%x

		    REM Extract Unused %
		    for /f "tokens=1" %%y in ("!WASTE_LINE!") do set WASTE=%%y

		    REM Grab the line after colon
		    for /f "tokens=13*" %%x in ('findstr /c:"Unused Cache Space" temp.txt') do set WASTE2_LINE=%%x

		    REM Extract Waste $ and remove $
		    for /f "tokens=1" %%y in ("!WASTE2_LINE!") do set COST=%%y

		    REM Grab the line after colon
		    for /f "tokens=4*" %%x in ('findstr /c:"Total Page Fault" temp.txt') do set PAGE_FAULT_LINE=%%x
                    set PAGE_FAULT_LINE=!PAGE_FAULT_LINE: =!
  

                    REM -----------------------------
                    REM Append to CSV
                    REM -----------------------------
                    echo %TRACE%,%%c,%%b,%%a,%%p,!MISS!,!CPI!,!WASTE!,!COST!,%%m,!PAGE_FAULT_LINE! >> %OUT%

                )
            )
        )
    )
)

REM Clean up temp file
del temp.txt

echo.
echo Done! Results saved in %OUT%
echo Total simulation runs: !COUNT!
pause
